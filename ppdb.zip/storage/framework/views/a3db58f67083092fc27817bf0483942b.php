<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="background-image-path">
        <div class="container-fluid position-relative top-md-50 start-md-50 translate-md-middle mt-5">
            <div class="container justify-content-center">
                <h2 class="text-white poppins-medium text-center text-shadow">
                    Jalur Pendaftaran PPDB
                </h2>
                <h1 class="text-white poppins-bold text-center text-shadow">
                    SMA UNGGULAN RUSHD
                </h1>
            </div>
            <div class="container mt-5 mb-5 mb-md-0">
                <form action="<?php echo e(route('pendaftaran.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row justify-content-center g-5">
                        <div class="col-md-8 col-lg-3">
                            <div class="card border-0">
                                <div class="card-header bg-orange text-white text-center poppins-medium">
                                    Jalur Reguler
                                </div>
                                <img src="/assets/kata-umum-dan-khususjpg-20230104124939.jpg"
                                    class="card-img card-image-size" alt="card-image" />
                                <div class="card-body">
                                    <h5 class="card-title text-center poppins-bold">
                                        Jalur Reguler
                                    </h5>
                                    <p class="card-text card-paragraph">
                                        Pendaftaran untuk jalur reguler, terbuka bagi semua siswa
                                        yang memenuhi syarat umum.
                                    </p>
                                    <div class="d-grid justify-content-center">
                                        <button type="submit" value="reguler" name="jenis_pendaftaran"
                                            class="btn btn-orange text-white">Daftar Jalur Reguler</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 col-lg-3">
                            <div class="card border-0">
                                <div class="card-header bg-orange text-white text-center poppins-medium">
                                    Jalur Prestasi
                                </div>
                                <img src="/assets/pengertian-prestasi-macam-prestasi-menurut-para-ahli-5c0c6768bde5756aec02cb78.jpg"
                                    class="card-img card-image-size" alt="card-image" />
                                <div class="card-body">
                                    <h5 class="card-title text-center poppins-bold">
                                        Jalur Prestasi
                                    </h5>
                                    <p class="card-text card-paragraph">
                                        Pendaftaran untuk jalur prestasi, terbuka bagi siswa dengan
                                        prestasi akademik atau non-akademik
                                    </p>
                                    <div class="d-grid justify-content-center">
                                        <button type="submit" value="prestasi" name="jenis_pendaftaran"
                                            class="btn btn-orange text-white">Daftar Jalur Prestasi</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ppdb-website\resources\views/user/pendaftaran.blade.php ENDPATH**/ ?>