<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container justify-content-center d-flex">
        <div class="col-lg-7 shadow-lg p-3 mb-5 mt-5 bg-white rounded py-4 px-4">
            <div class="bg-orange rounded-top text-center py-2">
                <h3 class="text-white poppins-medium">Pendaftaran PPDB</h3>
                <h1 class="text-white poppins-semibold">SMA Unggulan Rushd</h1>
            </div>
            <div class="mt-4">
                <p class="poppins-regular">
                    Untuk mendukung kelancaran proses administrasi pembayaran biaya
                    pendidikan di SMA Unggulan Rushd, berikut kami informasikan nomor
                    rekening Bank BRI yang dapat digunakan untuk melakukan pembayaran:
                </p>
                <strong class="poppins-bold">Bank BRI</strong>
                <p class="poppins-regular">
                    Nomor Rekening: 014001002717308<br />
                    Atas Nama: SMA Unggulan Rushd <br />
                    Biaya Registrasi: Rp.500.000,-
                </p>
                <h5 class="poppins-regular">Instruksi Pembayaran:</h5>
                <ol class="poppins-regular">
                    <li>
                        Silakan melakukan transfer sesuai dengan jumlah yang telah
                        ditentukan melalui ATM, Mobile Banking, atau Internet Banking ke
                        nomor rekening di atas.
                    </li>
                    <li>
                        Setelah melakukan transfer, harap segera mengunggah bukti transfer
                        sebagai konfirmasi pembayaran.
                    </li>
                </ol>
            </div>
            <form action="<?php echo e(route('transfer.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="buktiTransfer" class="form-label noto-sans-regular">
                        Upload Bukti Transfer:
                    </label>
                    <input type="file" class="form-control border-orange" id="buktiTransfer" name="bukti_transfer"
                        required />
                </div>

                <div class="form-group mb-3">
                    <label for="sumberInformasi" class="form-label noto-sans-regular">
                        Informasi SMA Unggulan didapatkan dari:
                    </label>
                    <select class="form-select border-orange" id="sumberInformasi" name="sumber_informasi" required>
                        <option selected disabled>Pilih sumber</option>
                        <option value="Keluarga">Keluarga</option>
                        <option value="Rekan">Rekan</option>
                        <option value="Media Sosial">Media Sosial</option>
                        <option value="Website">Website</option>
                        <option value="Iklan">Iklan</option>
                        <option value="Brosur">Brosur</option>
                    </select>
                </div>

                <div class="d-grid">
                    <button type="submit" class="btn btn-orange text-white mt-3">
                        Kirim
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ppdb-website\resources\views/user/transfer.blade.php ENDPATH**/ ?>