<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Login <?php $__env->endSlot(); ?>
    <div class="background-image-login">
        <div class="container-fluid pt-4 d-md-block d-flex justify-content-center">
            <img class="logo-sekolah" src="/assets/cropped-Logo-SMA-Unggulan-RUSHD-05-1 1.png" alt="" />
        </div>
        <div class="container">
            <div class="row justify-content-lg-start justify-content-md-center">
                <div class="col-lg-4 col-md-8">
                    <div class="form-container-orange p-5 rounded mt-5">
                        <h2 class="text-white text-center poppins-medium mt-3">
                            Sign In
                        </h2>
                        <p class="poppins-extralight text-center text-white psection">
                            Let’s build something greate
                        </p>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="email" class="form-label poppins-light text-white form-text-14">Email
                                    address</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    value="<?php echo e(old('email')); ?>" aria-describedby="emailHelp" placeholder="Enter email"
                                    required autofocus />
                            </div>
                            <div class="mb-3">
                                <label for="password"
                                    class="form-label poppins-light text-white form-text-14">Password</label>
                                <div class="input-group" id="show_hide_password">
                                    <input class="form-control" type="password" placeholder="Password" id="password"
                                        name="password" required />
                                    <button class="btn btn-light" type="button">
                                        <i class="fa fa-eye-slash text-dark" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <?php if($errors->any()): ?>)
                                    <small class="text-danger my-1 fw-light error-text">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </small>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 poppins-semibold">
                                Login
                            </button>
                        </form>
                        <div class="d-flex justify-content-end mt-2">
                            <?php if(Route::has('password.request')): ?>
                                <a href="<?php echo e(route('password.request')); ?>"
                                    class="text-white poppins-extralight form-text-14 link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover">Forgot
                                    Password</a>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex justify-content-center mt-3">
                            <p class="poppins-light">
                                Don’t have an account? &nbsp;
                            </p>
                            <a href="<?php echo e(route('register')); ?>"
                                class="text-white poppins-light link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover">
                                Sign Up</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 d-none d-lg-block">
                    <div class="position-relative top-50 start-50 translate-middle">
                        <h3 class="text-black noto-sans-bold">
                            SMA Unggulan RUSHD
                        </h3>
                        <h2 class="text-black koh-santepheap-bold">
                            School of Future Innovative Leader
                        </h2>
                        <br />
                        <p class="text-black noto-sans-regular">
                            Kami memiliki concern dalam mempersiapkan para
                            pemimpin masa depan yang profesional dan dapat
                            bersaing pada revolusi industri 4.0 dan society
                            5.0
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ppdb-website\resources\views/auth/login.blade.php ENDPATH**/ ?>