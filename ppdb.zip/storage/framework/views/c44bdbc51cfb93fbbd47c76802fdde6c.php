<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container justify-content-center d-flex">
        <div class="col-md-10 col-lg-8">
            <div class="shadow-lg p-3 mb-5 mt-5 justify-content-center bg-white rounded-3">
                <div class="mt-5">
                    <h2 class="text-center text-orange poppins-bold">
                        Isi Biodata Calon Siswa
                    </h2>
                    <div class="step mt-4">
                        <span class="circle active">1</span>
                        <span class="line"></span>
                        <span class="circle">2</span>
                        <span class="line"></span>
                        <span class="circle">3</span>
                        <span class="line"></span>
                        <span class="circle">4</span>
                    </div>
                </div>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">

                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="mx-md-5 mx-2 mb-5">
                    <form action="<?php echo e(route('biodata.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_pendaftaran" value="<?php echo e($data->id); ?>">
                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="namaLengkap">Nama Lengkap:</label>
                            <input type="text" class="form-control border-orange" id="namaLengkap" name="name"
                                value="<?php echo e(old('name')); ?>" placeholder="Masukkan nama lengkap" required />
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="asalSekolah">Asal Sekolah:</label>
                            <input type="text" class="form-control border-orange" id="asalSekolah"
                                name="asal_sekolah" value="<?php echo e(old('asal_sekolah')); ?>"
                                placeholder="Masukkan asal sekolah" required />
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="nisn">NISN:</label>
                            <input type="text" class="form-control border-orange" id="nisn" name="nisn"
                                value="<?php echo e(old('nisn')); ?>" placeholder="Masukkan NISN" required />
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="jenisKelamin">Jenis Kelamin:</label>
                            <select class="form-select border-orange" id="jenisKelamin" name="gender" required>
                                <option disabled selected>Pilih Jenis Kelamin</option>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label class="form-label noto-sans-regular" for="tempat">Tempat Lahir:</label>
                                    <input type="text" class="form-control border-orange" id="tempat"
                                        name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>"
                                        placeholder="Masukkan tempat lahir" required />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label class="form-label noto-sans-regular" for="tanggal">Tanggal Lahir:</label>
                                    <input type="date" class="form-control border-orange" id="tanggal"
                                        name="tgl_lahir" value="<?php echo e(old('tgl_lahir')); ?>" required />
                                </div>
                            </div>
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="alamat">Alamat Rumah:</label>
                            <input type="text" class="form-control border-orange" id="alamat" name="alamat"
                                value="<?php echo e(old('alamat')); ?>" placeholder="Masukkan alamat rumah" required />
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="kabupatenKota">Kabupaten/Kota:</label>
                            <input type="text" class="form-control border-orange" id="kabupatenKota" name="kabupaten"
                                value="<?php echo e(old('kabupaten')); ?>" placeholder="Masukkan kabupaten/kota" required />
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="provinsi">Provinsi:</label>
                            <input type="text" class="form-control border-orange" id="provinsi" name="provinsi"
                                value="<?php echo e(old('provinsi')); ?>" placeholder="Masukkan provinsi" required />
                        </div>

                        <div class="form-group mb-3">
                            <label class="form-label noto-sans-regular" for="telepon">Nomor Telepon/HP:</label>
                            <input type="text" class="form-control border-orange" id="telepon" name="telepon"
                                value="<?php echo e(old('telepon')); ?>" placeholder="Masukkan nomor telepon/HP" required />
                        </div>

                        <div class="justify-content-end d-flex">
                            <button type="submit" class="btn btn-orange text-white mt-3">
                                Selanjutnya
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ppdb-website\resources\views/user/biodata.blade.php ENDPATH**/ ?>