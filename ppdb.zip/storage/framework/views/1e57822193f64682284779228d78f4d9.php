<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="position-absolute top-50 start-50 translate-middle">
        <div class="confirmation-card">
            <div class="justify-content-center text-center">
                <img src="/assets/Group 37301.png" alt="" />
                <h2 class="teks-berhasil poppins-bold">Data Sudah Tersimpan</h2>
                <p class="text-secondary">
                    Terimakasih telah mendaftar pada PPDB SMA Unggulan RUSHD untuk tahun
                    ajaran 2025/2026. Mohon tunggu informasi lebih lanjut untuk jadwal
                    tes dan interview.
                </p>
                <a href="<?php echo e(route('home')); ?>"><button class="btn btn-primary">Kembali ke Home</button></a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ppdb-website\resources\views/user/success.blade.php ENDPATH**/ ?>